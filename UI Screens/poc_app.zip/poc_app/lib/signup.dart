import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'Home/index.dart';

class SignUpPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var screenSize = MediaQuery.of(context).size;
    var width = screenSize.width;
    var height = screenSize.height;
    debugPrint('width $width \n $height/2');
    // TODO: implement build
    return Scaffold(
      resizeToAvoidBottomPadding: false,
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[


          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only (top: 10.0),
                child: Stack(
                  children: <Widget>[
                    SingleChildScrollView(
                      padding: const EdgeInsets.all(8.0),

                          child: SingleChildScrollView(
                            child: Column(
                              children: <Widget>[

                                Padding(
                                  padding: EdgeInsets.symmetric(
                                      vertical: 6.0
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: TextField(
                                      autocorrect: false,
                                      autofocus: false,
                                      decoration: InputDecoration(
                                        labelText: "Email-id",
                                        labelStyle: TextStyle(
                                            fontSize: 20.0
                                        ),
                                        border: InputBorder.none,
                                        focusedBorder: UnderlineInputBorder(
                                            borderRadius: BorderRadius.circular(15.0)

                                        ),

                                        filled: true,
                                        fillColor: Colors.pinkAccent[220],
                                        contentPadding: EdgeInsets.all(8.0),
                                      ),
                                    ),
                                  ),
                                ),

                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: TextField(
                                    autocorrect: false,
                                    autofocus: false,
                                    obscureText: true,
                                    decoration: InputDecoration(
                                      labelText: "Mobile Number",
                                      labelStyle: TextStyle(
                                          fontSize: 20.0
                                      ),
                                      border: InputBorder.none,
                                      focusedBorder: UnderlineInputBorder(
                                          borderRadius: BorderRadius.circular(15.0)
                                      ),

                                      filled: true,
                                      fillColor: Colors.pinkAccent[220],
                                      contentPadding: EdgeInsets.all(8.0),
                                    ),
                                  ),
                                ),

                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: TextField(

                                    autocorrect: false,
                                    autofocus: false,
                                    obscureText: true,
                                    decoration: InputDecoration(
                                      labelText: "Name",
                                      labelStyle: TextStyle(
                                          fontSize: 20.0
                                      ),
                                      border: InputBorder.none,
                                      focusedBorder: UnderlineInputBorder(
                                          borderRadius: BorderRadius.circular(15.0)
                                      ),

                                      filled: true,
                                      fillColor: Colors.pinkAccent[220],
                                      contentPadding: EdgeInsets.all(8.0),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: TextField(
                                    autocorrect: false,
                                    autofocus: false,
                                    obscureText: true,
                                    decoration: InputDecoration(
                                      labelText: "Specialization",
                                      labelStyle: TextStyle(
                                          fontSize: 20.0
                                      ),
                                      border: InputBorder.none,
                                      focusedBorder: UnderlineInputBorder(
                                          borderRadius: BorderRadius.circular(15.0)
                                      ),

                                      filled: true,
                                      fillColor: Colors.pinkAccent[220],
                                      contentPadding: EdgeInsets.all(8.0),
                                    ),
                                  ),
                                ),

                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: TextField(
                                    autocorrect: false,
                                    autofocus: false,
                                    obscureText: true,
                                    decoration: InputDecoration(
                                      labelText: "Highest Degrees",
                                      labelStyle: TextStyle(
                                          fontSize: 20.0
                                      ),
                                      border: InputBorder.none,
                                      focusedBorder: UnderlineInputBorder(
                                          borderRadius: BorderRadius.circular(15.0)
                                      ),

                                      filled: true,
                                      fillColor: Colors.pinkAccent[220],
                                      contentPadding: EdgeInsets.all(8.0),
                                    ),
                                  ),
                                ),

                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: TextField(
                                    autocorrect: false,
                                    autofocus: false,
                                    obscureText: true,
                                    decoration: InputDecoration(
                                      labelText: "Medical License",
                                      labelStyle: TextStyle(
                                          fontSize: 20.0
                                      ),
                                      border: InputBorder.none,
                                      focusedBorder: UnderlineInputBorder(
                                          borderRadius: BorderRadius.circular(15.0)
                                      ),

                                      filled: true,
                                      fillColor: Colors.pinkAccent[220],
                                      contentPadding: EdgeInsets.all(8.0),
                                    ),
                                  ),
                                ),


                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: TextField(
                                    autocorrect: false,
                                    autofocus: false,
                                    obscureText: true,
                                    decoration: InputDecoration(
                                      labelText: "Password",
                                      labelStyle: TextStyle(
                                          fontSize: 20.0
                                      ),
                                      border: InputBorder.none,
                                      focusedBorder: UnderlineInputBorder(
                                          borderRadius: BorderRadius.circular(15.0)
                                      ),

                                      filled: true,
                                      fillColor: Colors.pinkAccent[220],
                                      contentPadding: EdgeInsets.all(8.0),
                                    ),
                                  ),
                                ),


                                MaterialButton(onPressed: () {
                                  navigateToHomePage (context);
                                },
                                  color: Colors.pinkAccent,
                                  minWidth: 200,
                                  splashColor: Colors.red[800],
                                  padding: EdgeInsets.symmetric(
                                    vertical: 12.0,
                                  ),
                                  child: Text(
                                    "Register",
                                    style: TextStyle(
                                      fontSize: 18.0,
                                      color: Colors.white,

                                    ),
                                  ),
                                ),


                              ],

                            ),
                          ),

                        ),
                  ],
                ),
              ),
            ],
          ),

        ],
      ),
    );
  }
  Future navigateToHomePage(context) async {
    Navigator.push(context, MaterialPageRoute(builder: (context) => HomeScreen()));
  }



/* Widget _buildTextFied(
      BuildContext context, String labelText, bool isPassowrd) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 12.0),
      child: Theme(
        data: Theme
            .of(context)
            .copyWith(primaryColor: Colors.white.withOpacity(0.5)),
        child: TextField(
          obscureText: isPassowrd,
          focusNode: FocusNode(),
          style: TextStyle(
            color: Colors.white,
          ),
          decoration: InputDecoration(
            labelText: labelText,
            labelStyle: Theme.of(context).textTheme.body1,
          ),
        ),
      ),
    );
  }
*/
}