import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:pocapp/signup.dart';
import 'package:pocapp/signupseekers.dart';
import 'package:toggle_switch/toggle_switch.dart';

import 'Components/customswitch.dart';
import 'Components/lite_rolling_switch.dart';
import 'Home/index.dart';
import 'Home/patientindex.dart';

class LoginPage extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => LoginPageState();
}
enum AccountType {
  DoctorSeeker,
  Doctor,
}

class LoginPageState extends State<LoginPage>{
  AccountType _selectedItem;

  var val=0;
  var string='Are you a patient?';

  var pressed=false;



  @override
  Widget build(BuildContext context) {
    var  _currentIndex = 1;
    AccountType _character = AccountType.DoctorSeeker;
    var screenSize = MediaQuery.of(context).size;
    var width = screenSize.width;
    var height = screenSize.height;
    debugPrint('width $width \n $height/2');
    // TODO: implement build
    return Scaffold(
      resizeToAvoidBottomPadding: false,
          body: Stack(
            fit: StackFit.expand,
            children: <Widget>[


              Image.asset('assets/images/pinkbg.jpg',fit: BoxFit.cover,  color: Colors.black54,
                  colorBlendMode: BlendMode.darken),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Image.asset('assets/images/ribbon.png',fit: BoxFit.cover,height: 80.0,width: 80.0,),
                Padding(
                  padding: const EdgeInsets.only (top: 4.0),
                  child: Stack(
                    children: <Widget>[
                      SingleChildScrollView(
                        padding: const EdgeInsets.all(4.0),
                        child: Card(
                          elevation: 8.0,
                          shape: new RoundedRectangleBorder(
                            borderRadius:new BorderRadius.circular(25.0),

                          ),
                          child: Container(
                            height: 330.0,
                            width: width/2+width/2.5,
                            padding: EdgeInsets.symmetric(
                              horizontal: 30.0,
                              vertical: 25.0,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.rectangle,
                              borderRadius: BorderRadius.circular(25.0)
                            ),
                            child: SingleChildScrollView(
                              child: Column(
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.only(top: 2.0),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: <Widget>[
                                        /*new Text(string,
                                          style: pressed
                                              ? TextStyle(color: Colors.black)
                                              : TextStyle(color:Colors.green),
                                        ),*/
                                        new FlatButton(
                                          child: new Text(
                                              '$string'),
                                          onPressed: () {
                                            setState(() {
                                              pressed = !pressed;
                                              switch(pressed)
                                              {
                                                case true:
                                                  string="Are you a doctor.";
                                                  val=1;
                                                  break;

                                                case false:
                                                  string="Are you a patient.";
                                                  val=0;
                                                  break;

                                              }
                                            });
                                          },
                                          splashColor: Colors.white,
                                          textColor: Colors.pinkAccent,
                                        )
                                      ],
                                    ),
                                  ),



                                  Padding(
                                    padding: EdgeInsets.symmetric(
                                      vertical: 8.0
                                    ),
                                    child: TextField(
                                      autocorrect: false,
                                      autofocus: false,
                                      decoration: InputDecoration(
                                        labelText: "Email-id/Mobile Number",
                                        labelStyle: TextStyle(
                                            fontSize: 20.0
                                        ),
                                        border: InputBorder.none,
                                        focusedBorder: UnderlineInputBorder(
                                            borderRadius: BorderRadius.circular(15.0)

                                        ),

                                        filled: true,
                                        fillColor: Colors.pinkAccent[220],
                                        contentPadding: EdgeInsets.all(8.0),
                                      ),
                                    ),
                                  ),

                                  TextField(
                                    autocorrect: false,
                                    autofocus: false,
                                    obscureText: true,
                                    decoration: InputDecoration(
                                      labelText: "Password",
                                      labelStyle: TextStyle(
                                          fontSize: 20.0
                                      ),
                                      border: InputBorder.none,
                                      focusedBorder: UnderlineInputBorder(
                                          borderRadius: BorderRadius.circular(15.0)
                                      ),

                                      filled: true,
                                      fillColor: Colors.pinkAccent[220],
                                      contentPadding: EdgeInsets.all(8.0),
                                    ),
                                  ),
                                 /* Padding(
                                    padding: EdgeInsets.only(top: 8.0,bottom: 8.0),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: <Widget>[
                                        Text(
                                          "Forgot Password?",
                                          style: TextStyle(
                                            fontSize: 12.0,
                                            fontWeight: FontWeight.w800,
                                            color: Colors.pink,

                                          ),
                                        )
                                      ],
                                    ),
                                  ),*/
                                  //CrazySwitch(),
                                /*  LiteRollingSwitch(
                                    //initial value
                                    value: true,
                                    textOn: 'not a doctor',
                                    textOff: 'are you a doctor',
                                    colorOn: Colors.greenAccent[700],
                                    colorOff: Colors.redAccent[700],
                                    iconOn: Icons.done,
                                    iconOff: Icons.remove_circle_outline,
                                    textSize: 16.0,
                                    onChanged: (bool state) {
                                      //Use it to manage the different states
                                      print('Current State of SWITCH IS: $state');
                                    },
                                  ),*/

                                 Padding(
                                   padding: const EdgeInsets.all(8.0),
                                   child: MaterialButton(onPressed: () {
                                     switch(val){
                                       case 0:
                                         navigateToPatientDashboard(context);
                                         break;
                                       case 1:
                                         navigateToDoctorDashboard(context);
                                         break;
                                       default:
                                         navigateToPatientDashboard(context);

                                     }
                                   },
                                     color: Colors.pinkAccent,
                                     minWidth: 200,
                                     splashColor: Colors.red[800],
                                     padding: EdgeInsets.symmetric(
                                       vertical: 12.0,
                                     ),
                                   child: Text(
                                     "Sign In",
                                     textAlign: TextAlign.left,
                                     style: TextStyle(
                                       fontSize: 18.0,
                                       color: Colors.white,

                                     ),
                                   ),
                                   ),
                                 ),


                                 MaterialButton(onPressed: () {
                                   switch(val){
                                     case 0:
                                       navigateToSeekersPage(context);
                                       break;
                                     case 1:
                                       navigateToSubPage(context);
                                       break;
                                     default:
                                       navigateToSeekersPage(context);

                                   }
                                 },
                                   minWidth: 100,
                                   splashColor: Colors.red[800],
                                   padding: EdgeInsets.symmetric(
                                     vertical: 8.0,
                                   ),
                                   child: Text(
                                     "Not having account? Create now.",

                                     softWrap: true,
                                     maxLines: 2,
                                     textAlign: TextAlign.center,
                                     style: TextStyle(
                                       fontSize: 16.0,
                                       color: Colors.pinkAccent,

                                     ),
                                   ),
                                 ),

                                ],

                              ),
                            ),

                          ),
                        ),
                      )
                    ],
                  ),
                ),
                ],
              ),

            ],
          ),
    );
  }
  Future navigateToSubPage(context) async {
    Navigator.push(context, MaterialPageRoute(builder: (context) => SignUpPage()));
  }Future navigateToSeekersPage(context) async {
    Navigator.push(context, MaterialPageRoute(builder: (context) => SignUpSeekersPage()));
  }
Future navigateToPatientDashboard(context) async {
    Navigator.push(context, MaterialPageRoute(builder: (context) => PatientHomeScreen()));
  }
Future navigateToDoctorDashboard(context) async {
    Navigator.push(context, MaterialPageRoute(builder: (context) => HomeScreen()));
  }



  /* Widget _buildTextFied(
      BuildContext context, String labelText, bool isPassowrd) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 12.0),
      child: Theme(
        data: Theme
            .of(context)
            .copyWith(primaryColor: Colors.white.withOpacity(0.5)),
        child: TextField(
          obscureText: isPassowrd,
          focusNode: FocusNode(),
          style: TextStyle(
            color: Colors.white,
          ),
          decoration: InputDecoration(
            labelText: labelText,
            labelStyle: Theme.of(context).textTheme.body1,
          ),
        ),
      ),
    );
  }
*/
}