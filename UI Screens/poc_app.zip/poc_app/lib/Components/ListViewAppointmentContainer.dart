import 'package:flutter/material.dart';
import 'package:pocapp/Home/styles.dart';
import 'List.dart';
import 'Calender.dart';

class ListViewAppointmentContent extends StatelessWidget {
  final Animation<double> listTileWidth;
  final Animation<Alignment> listSlideAnimation;
  final Animation<EdgeInsets> listSlidePosition;
  ListViewAppointmentContent({
    this.listSlideAnimation,
    this.listSlidePosition,
    this.listTileWidth,
  });
  @override
  Widget build(BuildContext context) {
    return (new Stack(
      alignment: listSlideAnimation.value,
      children: <Widget>[

        Padding(
          padding: const EdgeInsets.only(top:2.0),
          child: new ListData(
              margin: listSlidePosition.value * 7.5,
              width: listTileWidth.value,
              title: "Aarthi",
              subtitle: "gynacologist",
              image: avatar6,
              appointment: "Book Appointment"
          ),
        ),

        new ListData(
            margin: listSlidePosition.value * 6.5,
            width: listTileWidth.value,
            title: "Neha",
            subtitle: "Dentist",
            image: avatar6,
            appointment: 'Book Appointment'
            ),

        new ListData(
            margin: listSlidePosition.value * 5.5,
            width: listTileWidth.value,
            title: "Nikhila",
            subtitle: "cardio",
            image: avatar6,
            appointment: 'Book Appointment'),
        new ListData(
            margin: listSlidePosition.value * 4.5,
            width: listTileWidth.value,
            title: "Harry",
            subtitle: "Pediatrician",
            image: avatar1,
            appointment: 'Book Appointment'),
        new ListData(
            margin: listSlidePosition.value * 3.5,
            width: listTileWidth.value,
            title: "Jessi",
            subtitle: "Cardio",
            image: avatar5,
            appointment: 'Book Appointment'),
        new ListData(
            margin: listSlidePosition.value * 2.5,
            width: listTileWidth.value,
            title: "Janet",
            subtitle: "Pediatrician",
            image: avatar4,
            appointment: 'Book Appointment'),
        new ListData(
            margin: listSlidePosition.value * 1.5,
            width: listTileWidth.value,
            title: "Tom",
            subtitle: "Dentist",
            image: avatar2,
            appointment: 'Book Appointment'),
        new ListData(
            margin: listSlidePosition.value * 0.5,
            width: listTileWidth.value,
            title: "Rock",
            subtitle: "Physio",
            image: avatar3,
            appointment: 'Book Appointment'),
      ],
    ));
  }
}

//For large set of data

//import '../Screens/Home/data.dart';
// DataListBuilder dataListBuilder = new DataListBuilder();
// var i = dataListBuilder.rowItemList.length + 0.5;
// children: dataListBuilder.rowItemList.map((RowBoxData rowBoxData) {
//   return new ListData(
//     title: rowBoxData.title,
//     subtitle: rowBoxData.subtitle,
//     image: rowBoxData.image,
//     width: listTileWidth.value,
//     margin: listSlidePosition.value * (--i).toDouble(),
//   );
// }).toList(),
